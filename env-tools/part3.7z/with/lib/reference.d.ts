import * as t from '@babel/types';
export default function isReferenced(node: t.Node, parent: t.Node): boolean;
